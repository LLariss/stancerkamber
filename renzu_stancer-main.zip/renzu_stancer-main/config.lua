Config = {}

Config.Mysql = 'oxmysql' -- mysql-async, ghmattisql, oxmysql
Config.weight_type = true
Config.weight = 1.5
Config.Framework = 'Standalone' -- ESX,QBCORE,Standalone (ITEM PURPOSE ONLY)
Config.FixedCamera = true

--COMMANDS AND KEYBINDS
Config.commands = 'stance'
Config.keybinds = ''

--FRAMEWORK--
Config.items = {
    'stancerkit',
}